package application.view;

import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.chart.*;
import javafx.scene.control.Alert;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;
import javafx.stage.Stage;
import model.data.Measure;
import model.data.Room;
import application.SyncData;

import java.io.IOException;
import java.nio.file.*;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Contrôleur pour gérer l'affichage des graphiques de données pour les salles et les panneaux solaires.
 * <p>
 * Cette classe est responsable de l'affichage des données sous forme de graphiques interactifs (barres et courbes) dans une interface JavaFX.
 * Elle permet de surveiller les alertes et les nouveaux fichiers de données via un mécanisme de surveillance de fichiers.
 * </p>
 *
 * @author Marwane Ibrahim
 */
public class GraphiquesController {

    private Map<String, Map<String, Double>> sensorData = new HashMap<>();
    private ExecutorService alertExecutor;
    private ExecutorService dataExecutor;
    private volatile boolean running = true;

    @FXML
    private TabPane tabPane;
    private Stage containingStage;


    public void initContext(Stage containingStage){
        this.containingStage = containingStage;
    }

    /**
     * Initialise le contrôleur, charge les données des salles et crée les onglets de graphiques.
     *
     * Cette méthode est appelée lors de l'initialisation du contrôleur. Elle charge les données des salles et des panneaux solaires via le singleton {@link SyncData}.
     * Elle crée ensuite des onglets de graphiques pour chaque type de donnée et lance des threads pour surveiller les alertes et les fichiers de données.
     */
    public void initialize() {
        try {
            SyncData syncData = SyncData.getInstance();

            // Créer les onglets pour chaque type de donnée
            for (Room room : syncData.getRoomsMap().values()) {
                for (Measure measure : room.getRoomValues()) {
                    for (Map.Entry<String, Object> entry : measure.getValues().entrySet()) {
                        String key = entry.getKey();
                        double value = ((Number) entry.getValue()).doubleValue();
                        sensorData.computeIfAbsent(key, k -> new HashMap<>()).put(room.getRoomName(), value);
                    }
                }
            }

            // Crée un onglet pour chaque type de donnée
            for (String key : sensorData.keySet()) {
                Tab tab = new Tab(key);
                tab.setContent(createChart(key, sensorData.get(key)));
                tabPane.getTabs().add(tab);
            }


        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    /**
     * Démarre la surveillance des fichiers de données dans un répertoire spécifique.
     * Lorsqu'un nouveau fichier de données est créé dans ce répertoire, il sera chargé pour mettre à jour les graphiques.
     *
     * @param dataDir Le répertoire à surveiller pour les fichiers de données.
     */
    private void startDataMonitoring(Path dataDir) {
        dataExecutor = Executors.newSingleThreadExecutor();

        dataExecutor.submit(() -> {
            try {
                WatchService watchService = FileSystems.getDefault().newWatchService();
                dataDir.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);

                while (running) {
                    WatchKey key;
                    try {
                        key = watchService.poll();
                        if (key == null) {
                            Thread.sleep(100);
                            continue;
                        }
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }

                    for (WatchEvent<?> event : key.pollEvents()) {
                        if (event.kind() == StandardWatchEventKinds.ENTRY_CREATE) {
                            Path filePath = dataDir.resolve((Path) event.context());
                            // Chargement des données des fichiers (implémentez selon votre logique)
                            // loadSensorData(filePath);
                        }
                    }
                    key.reset();
                }

                watchService.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    /**
     * Crée un graphique en fonction du type de donnée (barres ou courbes).
     *
     * @param key   Le nom de la donnée (utilisé pour déterminer si c'est une courbe ou un histogramme).
     * @param data  Les données à afficher dans le graphique.
     * @return Le graphique créé (soit un graphique à barres, soit un graphique linéaire).
     */
    private Chart createChart(String key, Map<String, Double> data) {
        if (key.equalsIgnoreCase("pressure") || key.equalsIgnoreCase("temperature")) {
            return createLineChart(key, data);
        } else {
            return createBarChart(key, data);
        }
    }

    /**
     * Crée un graphique à barres pour afficher les données.
     *
     * @param key   Le nom de la donnée.
     * @param data  Les données à afficher sous forme de barres.
     * @return Un graphique à barres représentant les données.
     */
    private BarChart<String, Number> createBarChart(String key, Map<String, Double> data) {
        BarChart<String, Number> barChart = new BarChart<>(new CategoryAxis(), new NumberAxis());
        barChart.setTitle("Données : " + key);

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName(key);

        for (Map.Entry<String, Double> entry : data.entrySet()) {
            series.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
        }

        barChart.getData().add(series);
        return barChart;
    }

    /**
     * Crée un graphique linéaire pour afficher les données.
     *
     * @param key   Le nom de la donnée.
     * @param data  Les données à afficher sous forme de courbe.
     * @return Un graphique linéaire représentant les données.
     */
    private LineChart<String, Number> createLineChart(String key, Map<String, Double> data) {
        LineChart<String, Number> lineChart = new LineChart<>(new CategoryAxis(), new NumberAxis());
        lineChart.setTitle("Données : " + key);

        XYChart.Series<String, Number> series = new XYChart.Series<>();
        series.setName(key);

        for (Map.Entry<String, Double> entry : data.entrySet()) {
            series.getData().add(new XYChart.Data<>(entry.getKey(), entry.getValue()));
        }

        lineChart.getData().add(series);
        return lineChart;
    }

    /**
     * Gère l'événement de clic sur le bouton "Retour" et permet de revenir à l'écran précédent.
     */
    @FXML
    private void handleButtonRetour() {
        this.containingStage.close();
    }

    /**
     * Arrête les exécutants en cours (surveillance des alertes et des données).
     * Cette méthode doit être appelée lorsque le contrôleur n'est plus nécessaire ou lors de la fermeture de l'application.
     */
    public void stop() {
        try {
            if (alertExecutor != null && !alertExecutor.isShutdown()) {
                alertExecutor.shutdownNow();
            }
            if (dataExecutor != null && !dataExecutor.isShutdown()) {
                dataExecutor.shutdownNow();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
